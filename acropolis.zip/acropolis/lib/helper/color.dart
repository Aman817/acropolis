import 'package:flutter/material.dart';

const Color ui = Color(0XFF733cc8);
const Color ui1 = Color(0XFFf2e5fb);
